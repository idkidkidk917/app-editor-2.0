# CART3R ULTRA — Android starter project

An original Kotlin/Jetpack Compose video-editor project shell targeting Android 10 (API 29) and newer.

## Included in this source build
- Native Android app structure using Kotlin and Jetpack Compose
- Media3 ExoPlayer video preview
- Android document picker for video and audio assets
- Timeline-oriented UI with video/audio/text tracks
- UI controls for trim points, speed, volume, caption text, effects selection, and chroma-key mode
- AI assistant placeholder with an explicit privacy/service integration note
- Dark crimson CART3R ULTRA branding

## Important implementation status
This is a **buildable editor prototype**, not a finished CapCut-equivalent rendering engine. The UI stores editing controls in screen state. Export-time trimming, compositing, effects, audio mixing, speed ramps, chroma key, caption burn-in, and AI inference are not wired into a render pipeline yet. The Export button intentionally reports this rather than creating a misleading or broken output.

A production implementation should use a tested media pipeline (for example, AndroidX Media3 Transformer where its supported effects meet the requirements, plus custom OpenGL effects for chroma key and compositing). 4K export depends on source resolution, codec support, memory, and the device's hardware encoder; it cannot be guaranteed on every Android 10+ device.

## Requirements
- Android Studio with Android SDK Platform 35
- JDK 17
- Android Gradle Plugin 8.7.3 / Gradle 8.9
- Android device or emulator running Android 10+ (API 29+)

## Build an APK
1. Unzip this project.
2. Open the `CART3R_ULTRA` folder in Android Studio.
3. Allow Gradle sync to finish and install any prompted SDK components.
4. Connect an Android 10+ device with USB debugging enabled, or start an emulator.
5. For a debug APK, use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Find the output at `app/build/outputs/apk/debug/app-debug.apk`.
7. Install it on your own device. Android may ask you to allow installation from the file manager/browser you used.

Command line (from the project root):
```bash
gradle wrapper --gradle-version 8.9
./gradlew assembleDebug
```
On Windows:
```bat
gradlew.bat assembleDebug
```

For a signed release APK, use **Build > Generate Signed Bundle / APK... > APK**, create or select a keystore, and keep the keystore private and backed up.

## Project identity
- App name: CART3R ULTRA
- Application ID: `com.carter.ultra`
- Version: `1.0.0`
- Minimum SDK: 29 (Android 10)
- Target SDK: 35
- Language: Kotlin
