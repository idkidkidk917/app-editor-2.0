package com.carter.ultra

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

private val Ink = Color(0xFF09090D)
private val Panel = Color(0xFF17171F)
private val Crimson = Color(0xFFFF304F)
private val Muted = Color(0xFF9B9BA8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Cart3rApp() }
    }
}

@Composable
private fun Cart3rApp() {
    val context = LocalContext.current
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var audioUri by remember { mutableStateOf<Uri?>(null) }
    var caption by remember { mutableStateOf("Your caption") }
    var speed by remember { mutableFloatStateOf(1f) }
    var chromaEnabled by remember { mutableStateOf(false) }
    var selectedTool by remember { mutableStateOf("Timeline") }
    var showAi by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf("Import a clip to begin editing.") }

    val videoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) { }
            videoUri = uri
            notice = "Video added to the project."
        }
    }
    val audioPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) { }
            audioUri = uri
            notice = "Audio asset selected. Audio mixing is part of the export pipeline milestone."
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Crimson,
            background = Ink,
            surface = Panel,
            onPrimary = Color.White,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Ink,
            topBar = {
                Row(
                    Modifier.fillMaxWidth().background(Panel).padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("CART3R", color = Crimson, fontWeight = FontWeight.Black, fontSize = 22.sp)
                        Text("ULTRA  •  VIDEO STUDIO", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                    }
                    Button(
                        onClick = {
                            notice = if (videoUri == null) "Import a video before exporting."
                            else "Export engine scaffold is ready; rendering is not yet implemented in this starter build."
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Crimson),
                        shape = RoundedCornerShape(12.dp)
                    ) { Text("EXPORT") }
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("Timeline", "Effects", "Text", "Audio", "Tools").forEach { item ->
                        NavigationBarItem(
                            selected = selectedTool == item,
                            onClick = { selectedTool = item },
                            icon = {
                                Icon(
                                    when (item) {
                                        "Timeline" -> Icons.Default.Movie
                                        "Effects" -> Icons.Default.AutoAwesome
                                        "Text" -> Icons.Default.TextFields
                                        "Audio" -> Icons.Default.MusicNote
                                        else -> Icons.Default.Tune
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Crimson,
                                selectedTextColor = Crimson,
                                indicatorColor = Crimson.copy(alpha = .15f)
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Spacer(Modifier.height(2.dp))
                // Preview uses Media3 ExoPlayer when a clip is selected.
                VideoPreview(videoUri)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { videoPicker.launch(arrayOf("video/*")) },
                        modifier = Modifier.weight(1f)
                    ) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(5.dp)); Text("Add video") }
                    OutlinedButton(
                        onClick = { audioPicker.launch(arrayOf("audio/*")) },
                        modifier = Modifier.weight(1f)
                    ) { Icon(Icons.Default.MusicNote, null); Spacer(Modifier.width(5.dp)); Text("Add audio") }
                }
                Text(notice, color = Muted, fontSize = 12.sp)
                TimelinePanel(videoUri != null, audioUri != null)
                when (selectedTool) {
                    "Timeline" -> TimelineControls()
                    "Effects" -> EffectsPanel()
                    "Text" -> TextPanel(caption, { caption = it })
                    "Audio" -> AudioPanel(audioUri != null)
                    else -> ToolsPanel(
                        speed, { speed = it }, chromaEnabled, { chromaEnabled = it },
                        onAi = { showAi = true }
                    )
                }
                Text(
                    "PROJECT: ${if (videoUri == null) "EMPTY" else "1 VIDEO CLIP"}  •  SPEED: ${"%.2f".format(speed)}x",
                    color = Muted, fontSize = 10.sp, letterSpacing = 1.sp
                )
                Spacer(Modifier.height(10.dp))
            }
        }
        if (showAi) {
            AlertDialog(
                onDismissRequest = { showAi = false },
                title = { Text("AI ASSISTANT") },
                text = { Text("AI-assisted editing is represented by a safe local workflow placeholder. Connect a model service and define privacy, consent, and network behavior before enabling cloud AI features.") },
                confirmButton = {
                    TextButton(onClick = { showAi = false }) { Text("Got it") }
                },
                containerColor = Panel,
                titleContentColor = Color.White,
                textContentColor = Muted
            )
        }
    }
}

@Composable
private fun VideoPreview(uri: Uri?) {
    val context = LocalContext.current
    val player = remember(uri) {
        uri?.let {
            ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(it))
                prepare()
                playWhenReady = false
            }
        }
    }
    DisposableEffect(player) {
        onDispose { player?.release() }
    }
    Box(
        Modifier.fillMaxWidth().height(220.dp).background(Color.Black, RoundedCornerShape(18.dp)),
        contentAlignment = Alignment.Center
    ) {
        if (player != null) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        this.player = player
                        useController = true
                    }
                },
                update = { it.player = player },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.PlayCircle, null, tint = Crimson, modifier = Modifier.size(48.dp))
                Text("VIDEO PREVIEW", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
                Text("Import a clip to preview", color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun TimelinePanel(hasVideo: Boolean, hasAudio: Boolean) {
    Column(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("TIMELINE", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Text("00:00 / --:--", color = Muted, fontSize = 11.sp)
        }
        TimelineTrack("VIDEO", if (hasVideo) "Video clip • imported" else "No video clip", Crimson)
        TimelineTrack("AUDIO", if (hasAudio) "Audio asset • selected" else "No audio track", Color(0xFF38BDF8))
        TimelineTrack("TEXT", "Caption layer", Color(0xFFA78BFA))
    }
}

@Composable
private fun TimelineTrack(label: String, content: String, tint: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(label, color = Muted, fontSize = 9.sp, modifier = Modifier.width(42.dp))
        Box(
            Modifier.weight(1f).height(38.dp).background(tint.copy(alpha = .16f), RoundedCornerShape(8.dp))
                .padding(horizontal = 10.dp),
            contentAlignment = Alignment.CenterStart
        ) { Text(content, color = tint, fontSize = 11.sp) }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(title.uppercase(), color = Crimson, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        content()
    }
}

@Composable
private fun TimelineControls() {
    var start by remember { mutableFloatStateOf(0f) }
    var end by remember { mutableFloatStateOf(100f) }
    SectionCard("Clip controls") {
        Text("Start point: ${start.toInt()}%", color = Muted, fontSize = 12.sp)
        Slider(start, { start = it.coerceAtMost(end - 1f) }, valueRange = 0f..99f)
        Text("End point: ${end.toInt()}%", color = Muted, fontSize = 12.sp)
        Slider(end, { end = it.coerceAtLeast(start + 1f) }, valueRange = 1f..100f)
        Text("Trim controls are currently project UI state; export-time trimming is not wired in this starter.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun EffectsPanel() {
    var selected by remember { mutableStateOf("None") }
    SectionCard("Effects & transitions") {
        listOf("None", "Fade", "Warm", "Cool", "Monochrome", "Vignette", "Cross dissolve").forEach {
            FilterChip(selected == it, { selected = it }, label = { Text(it) })
        }
        Text("Selected: $selected • Effects preview/render integration is a next-stage task.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun TextPanel(caption: String, onCaption: (String) -> Unit) {
    SectionCard("Text & captions") {
        OutlinedTextField(
            value = caption,
            onValueChange = onCaption,
            label = { Text("Caption text") },
            modifier = Modifier.fillMaxWidth()
        )
        Text("Caption layer content is stored in the current screen state. Burn-in rendering is not yet connected.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun AudioPanel(hasAudio: Boolean) {
    var volume by remember { mutableFloatStateOf(80f) }
    SectionCard("Audio editing") {
        Text(if (hasAudio) "Audio asset selected" else "Choose an audio file with Add audio above.", color = Muted, fontSize = 12.sp)
        Text("Clip volume: ${volume.toInt()}%", color = Muted, fontSize = 12.sp)
        Slider(volume, { volume = it }, valueRange = 0f..100f)
        Text("Audio mixing, fades, and synchronization require the export pipeline implementation.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun ToolsPanel(
    speed: Float, onSpeed: (Float) -> Unit,
    chroma: Boolean, onChroma: (Boolean) -> Unit,
    onAi: () -> Unit
) {
    SectionCard("Speed ramping") {
        Text("${"%.2f".format(speed)}x playback speed", color = Muted, fontSize = 12.sp)
        Slider(speed, onSpeed, valueRange = .25f..4f)
        Text("The selected speed is a project setting; rendered speed changes are not yet connected.", color = Muted, fontSize = 11.sp)
    }
    SectionCard("Chroma key") {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Enable green-screen mode")
            Switch(chroma, onChroma)
        }
        Text("Key color selection and compositing are planned for the render engine.", color = Muted, fontSize = 11.sp)
    }
    SectionCard("AI-assisted tools") {
        Text("Concepts: auto captions, scene summaries, and edit suggestions.", color = Muted, fontSize = 12.sp)
        Button(onClick = onAi, colors = ButtonDefaults.buttonColors(containerColor = Crimson)) {
            Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(6.dp)); Text("Open AI assistant")
        }
    }
}

@Composable
private fun TimelineTrackSpacer() = Spacer(Modifier.height(1.dp))
